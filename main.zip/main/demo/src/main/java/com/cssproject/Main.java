package com.cssproject;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.security.NoSuchAlgorithmException;

public class Main {
    public static void main(String args[]) {

        JFrame jframe = new JFrame("GUI Screen");

        jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jframe.setSize(400, 150);
        JPanel panel = new JPanel();
        JLabel label = new JLabel("Enter password: "); // label
        JPasswordField passwordField = new JPasswordField(20); //password field
        JButton pressButton = new JButton("Done");  // Button object
        // Add components to the panel
        panel.add(label);
        panel.add(passwordField);
        panel.add(pressButton);

        // Add panel to the JFrame
        jframe.getContentPane().add(panel);

        GetHashed getHashed = new GetHashed();
        DictHashed dictHashed = new DictHashed();
        BruteForce bruteForce = new BruteForce();

        // ActionListener for button
        pressButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int length = passwordField.getDocument().getLength(); // Get the length of the password pass it for brute force
                try {
                    String hashedPassword = getHashed.getMd5Hash(new String(passwordField.getPassword()));
                    System.out.println("----------------Trying using hashed from list-----------------");
                    if(!dictHashed.found(hashedPassword)){
                        System.out.println("----------------Using Brute Force-----------------");
                        System.out.println("Password Matched \t"+ bruteForce.found(new String(passwordField.getPassword()), length));
                    }
                } catch (NoSuchAlgorithmException e1) {
                    System.out.println("No hashing algorithm found");
                    e1.printStackTrace();
                }
            }
        });

        jframe.setVisible(true);
    }
    
}
