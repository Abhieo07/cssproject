package com.cssproject;

import java.util.Random;

public class BruteForce {
    final String chars = "abcdefghijklmnopqrstuvwxyz0123456789";

    public String found(String userPwd, int length) {

        String samplePwd = generatePassword(chars, length);
        
        // Generate passwords until one matches the user-entered password
        while (!samplePwd.equals(userPwd)) {
            System.out.println(samplePwd);
            samplePwd = generatePassword(chars, length);
        }
        
        // Output the matching password
        return samplePwd;
        
    }

   // Function to generate a random password of a given length
    private static String generatePassword(String chars, int length) {
        Random random = new Random();
        StringBuilder password = new StringBuilder();

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(chars.length());
            password.append(chars.charAt(index));
        }

        return password.toString();
    }
}
