package com.cssproject;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.security.NoSuchAlgorithmException;

public class DictHashed {
    public  boolean found(String hashed) {
        BufferedReader reader = null;
        GetHashed getHashed = new GetHashed();
        try {
            String passwordFilePath = "dictionary.txt";

            // Open the password file
            reader = new BufferedReader(new FileReader(passwordFilePath));
            String line;

            // Process each password in the file
            while ((line = reader.readLine()) != null) {
                // Get the MD5 hash of the line
                String md5Hash = getHashed.getMd5Hash(line.trim());
                System.out.println(md5Hash);
                // Check if it matches the user's hashed input
                if (md5Hash.equals(hashed)) {
                    System.out.println("Password found: " + line);
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading file: " + e.getMessage());
        } catch (NoSuchAlgorithmException e) {
            System.out.println("MD5 algorithm not available.");
        } finally {
            // Close the file reader
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e) {
                    System.out.println("Error closing the file: " + e.getMessage());
                }
            }
        }
        return false;
        
    }

}
