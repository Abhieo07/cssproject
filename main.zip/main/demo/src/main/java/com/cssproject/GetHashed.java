package com.cssproject;
import java.security.MessageDigest;  
import java.security.NoSuchAlgorithmException;

public class GetHashed {
    public String getMd5Hash(String password) throws NoSuchAlgorithmException {
        // Get the MessageDigest instance for MD5
        MessageDigest md = MessageDigest.getInstance("MD5");
        md.update(password.getBytes());
        byte[] digest = md.digest();

        // Convert the byte array into a hexadecimal string
        StringBuilder sb = new StringBuilder();
        for (byte b : digest) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
