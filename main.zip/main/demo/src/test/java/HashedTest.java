import static org.junit.jupiter.api.Assertions.assertEquals;

import java.security.NoSuchAlgorithmException;

import org.junit.jupiter.api.Test;

import com.cssproject.GetHashed;

public class HashedTest {
    @Test
    public void testingmd5Algo(){
        GetHashed getHashed = new GetHashed();
        try {
            assertEquals("21523222c65d70ac44ac82905ff84561", getHashed.getMd5Hash("jeannie"));
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
