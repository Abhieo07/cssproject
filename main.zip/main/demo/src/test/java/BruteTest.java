import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.cssproject.BruteForce;

public class BruteTest {
    @Test
    public void testingBruteForce(){
        BruteForce bruteForce = new BruteForce();
        assertEquals("a2b", bruteForce.found("a2b", 3));
    }
}
