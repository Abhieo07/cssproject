import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

import com.cssproject.DictHashed;

import static org.junit.jupiter.api.Assertions.assertFalse;

public class DictTest {
    DictHashed hashed = new DictHashed();
    @Test
    public void testingTrue(){
        assertTrue(hashed.found("dcfc866c201ce95a295d28be30eb0c47"));
    }

    @Test
    public void testingFalse(){
        assertFalse(hashed.found("21523222c65d70ac44ac82905ff84516"));
    }
}
